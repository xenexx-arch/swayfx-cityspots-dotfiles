#!/bin/bash

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"

pkill -f "yad.*Calendar" 2>/dev/null
pkill -f "date-term" 2>/dev/null
pkill -f "yad.*Network" 2>/dev/null
pkill -f "yad.*Volume" 2>/dev/null

export LC_TIME=en_US.UTF-8

RESULT=$(
yad --calendar \
    --title="Calendar" \
    --width=380 \
    --height=320 \
    --no-buttons \
    --skip-taskbar \
    --undecorated \
    --fixed \
    --sticky \
    --on-top \
    --close-on-unfocus \
    --posx=1520 \
    --posy=20 \
    --date-format="%Y-%m-%d" \
    --css="
        window, window.background, .background { background-color: rgba(0,0,0,0); }
        calendar { background-color: rgba(0,0,0,0); color: #afc2c2; font-family: 'JetBrainsMono Nerd Font'; font-size: 15px; border: none; }
        calendar:selected { background-color: rgba(175,194,194,0.25); color: #ffffff; border-radius: 4px; }
        calendar.header { color: #afc2c2; font-weight: normal; border: none; }
        calendar.button { color: #afc2c2; border: none; }
        calendar.highlight { color: #afc2c2; border: none; }
        label { color: #afc2c2; font-family: 'JetBrainsMono Nerd Font'; font-size: 15px; background-color: rgba(0,0,0,0); }
        box, grid { background-color: rgba(0,0,0,0); }
    "
)

[ -n "$RESULT" ] && "$HOME/.config/waybar/scripts/show-date.sh" "$RESULT"
