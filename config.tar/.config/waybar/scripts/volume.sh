#!/bin/bash

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
export XDG_RUNTIME_DIR="/run/user/$(id -u)"

# Only kill on first launch, not on self-relaunch
if [ "$1" != "--relaunch" ]; then
    pkill -f "yad.*Volume" 2>/dev/null
    pkill -f "yad.*Network" 2>/dev/null
    pkill -f "yad.*Calendar" 2>/dev/null
fi

MAXLEN=35

read_vol() {
    wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null | awk '{print $2 * 100}' | cut -d. -f1 2>/dev/null
}

read_mute() {
    wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null | grep -o MUTED
}

read_dev() {
    local d
    d=$(wpctl status 2>/dev/null | sed -n '/Sinks:/,/Sources:/p' | grep '\*' | head -1 | sed 's/^[^0-9]*[0-9]*\.[[:space:]]*//' | sed 's/[[:space:]]*\[.*//')
    [ -z "$d" ] && d="unknown"
    echo "$d"
}

wrap_dev() {
    echo "$1" | fold -s -w "$MAXLEN" | awk 'NR==1{print "device: "$0} NR>1{print "        "$0}'
}

VOL=$(read_vol)
MUTE=$(read_mute)
DEV=$(read_dev)

if [ -n "$MUTE" ]; then
    INIT_VOL="muted"
else
    INIT_VOL="${VOL}%"
fi

TEXT="$(wrap_dev "$DEV")
volume: $INIT_VOL"

# Launch yad in the background, remember its PID for this run
yad --title="Volume" \
    --width=360 \
    --height=140 \
    --no-buttons \
    --skip-taskbar \
    --undecorated \
    --fixed \
    --sticky \
    --on-top \
    --close-on-unfocus \
    --posx=1520 \
    --posy=20 \
    --text="<span foreground='#afc2c2'>$TEXT</span>" \
    --css="
        window, window.background, .background { background-color: rgba(0,0,0,0); }
        label { color: #afc2c2; font-family: 'JetBrainsMono Nerd Font'; font-size: 15px; background-color: rgba(0,0,0,0); }
        box, grid { background-color: rgba(0,0,0,0); }
    " &
YAD_PID=$!

# Watchdog: every 200ms, if our yad is still alive, check if values changed.
# If changed, kill it and relaunch with fresh data — same position, same look.
LAST="$TEXT"
while kill -0 "$YAD_PID" 2>/dev/null; do
    VOL=$(read_vol)
    MUTE=$(read_mute)
    DEV=$(read_dev)
    if [ -n "$MUTE" ]; then
        NOW_VOL="muted"
    else
        NOW_VOL="${VOL}%"
    fi
    NOW="$(wrap_dev "$DEV")
volume: $NOW_VOL"

    if [ "$NOW" != "$LAST" ]; then
        kill "$YAD_PID" 2>/dev/null
        exec "$0" --relaunch
    fi
    sleep 0.2
done
