#!/bin/bash

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"

if [ ! -f /tmp/yad_cal_first ]; then
    touch /tmp/yad_cal_first
    exit 0
fi

pkill -f "date-term" 2>/dev/null

export LC_TIME=en_US.UTF-8

DATE_STR="$(date -d "$1" +'%A, %B %d, %Y')"
TIME_STR="$(date +'%H:%M:%S')"

kitty --class "date-term" \
      --title "date-term" \
      -o background=#000000 \
      -o background_opacity=0 \
      -o foreground=#afc2c2 \
      -o window_border_width=0 \
      -o draw_minimal_borders=no \
      -o confirm_os_window_close=0 \
      /bin/bash -c "
        printf '\n  %s\n  %s\n\n' '$DATE_STR' '$TIME_STR'
        echo '  press any key to exit'
        read -rsn1
      " &
