#!/bin/bash

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"

pkill -f "yad.*Windows" 2>/dev/null
pkill -f "yad.*Volume" 2>/dev/null
pkill -f "yad.*Network" 2>/dev/null
pkill -f "yad.*Calendar" 2>/dev/null

LIST=$(swaymsg -t get_tree 2>/dev/null | jq -r '
    ..
    | objects
    | select(.pid != null and .app_id != null and .name != null)
    | .name
' | sort -u)

[ -z "$LIST" ] && LIST="no windows open"

yad --title="Windows" \
    --width=500 \
    --height=400 \
    --no-buttons \
    --skip-taskbar \
    --undecorated \
    --fixed \
    --sticky \
    --on-top \
    --close-on-unfocus \
    --posx=20 \
    --posy=40 \
    --text="<span foreground='#afc2c2'>$LIST</span>" \
    --css="
        window, window.background, .background { background-color: rgba(0,0,0,0); }
        label { color: #afc2c2; font-family: 'JetBrainsMono Nerd Font'; font-size: 15px; background-color: rgba(0,0,0,0); }
        box, grid { background-color: rgba(0,0,0,0); }
    " &
