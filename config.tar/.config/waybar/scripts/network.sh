#!/bin/bash

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"

pkill -f "yad.*Network" 2>/dev/null
pkill -f "yad.*Volume" 2>/dev/null
pkill -f "yad.*Calendar" 2>/dev/null

IFACE=$(ip -4 route | grep default | awk '{print $5}' | head -1)

if [ -z "$IFACE" ]; then
    LINE1="status: disconnected"
    LINE2=""
    LINE3=""
else
    LOCAL_IP=$(ip -4 addr show "$IFACE" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
    [ -z "$LOCAL_IP" ] && LOCAL_IP="n/a"
    PUBLIC_IP=$(curl -s --max-time 3 ifconfig.me 2>/dev/null)
    [ -z "$PUBLIC_IP" ] && PUBLIC_IP="unavailable"

    if echo "$IFACE" | grep -qE '^(wl|wlan)'; then
        SSID=$(iw dev "$IFACE" info 2>/dev/null | grep -oP '(?<=ssid ).*')
        [ -z "$SSID" ] && SSID=$(nmcli -t -f ACTIVE,SSID dev wifi 2>/dev/null | grep '^yes' | cut -d: -f2)
        [ -z "$SSID" ] && SSID="unknown"
        LINE1="wifi: $SSID"
    else
        LINE1="handler: $IFACE"
    fi
    LINE2="public: $PUBLIC_IP"
    LINE3="local: $LOCAL_IP"
fi

yad --title="Network" \
    --width=360 \
    --height=160 \
    --no-buttons \
    --skip-taskbar \
    --undecorated \
    --fixed \
    --sticky \
    --on-top \
    --close-on-unfocus \
    --posx=1520 \
    --posy=20 \
    --text="<span foreground='#afc2c2'>$LINE1\n$LINE2\n$LINE3</span>" \
    --css="
        window, window.background, .background { background-color: rgba(0,0,0,0); }
        label { color: #afc2c2; font-family: 'JetBrainsMono Nerd Font'; font-size: 15px; background-color: rgba(0,0,0,0); }
        box, grid { background-color: rgba(0,0,0,0); }
    " &
