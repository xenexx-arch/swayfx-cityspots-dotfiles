#!/bin/bash
last_state=""

while true; do
  swaymsg -m -t subscribe '["window"]' 2>/dev/null | while read -r line; do
    if echo "$line" | grep -q '"change": "fullscreen_mode"'; then
      if echo "$line" | grep -q '"fullscreen_mode": 1' && [ "$last_state" != "1" ]; then
        echo "[$(date)] 🔒 FULLSCREEN"
        grep '^\s*bindsym' ~/.config/sway/config | awk '{print $2}' | while read -r key; do
          [ -n "$key" ] && swaymsg unbindsym "$key" 2>/dev/null
        done
        last_state="1"
      elif echo "$line" | grep -q '"fullscreen_mode": 0' && [ "$last_state" != "0" ]; then
        echo "[$(date)] 🔓 NORMAL"
        swaymsg reload 2>/dev/null
        last_state="0"
      fi
    fi
  done
  sleep 1
done
